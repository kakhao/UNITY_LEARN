﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PersScript : MonoBehaviour
{

    public float Speed = 1f;
    public Vector2 CurrentDestination = new Vector2(0f, 0f);

    public GameObject LinePrefab;
    private GameObject CurrRoute;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {


        //GameObject[] myTargets = GameObject.FindGameObjectsWithTag("Target1");
        //int n = myTargets.Length;
            //for (int i = 0; i < n; i++)
            //for (int i = 0; i < n; i++)
            //    myTargets[i].GetComponent<SpriteRenderer>().color = new Color32(140, 48, 10, 255);
            //float CurrentDestionX = 2f;
            //float CurrentDestionY = 3f;
            //GoTo(CurrentDestionX, CurrentDestionY);

         //GoTo(CurrentDestination);

    }


    void GoTo(Vector2 dest)
    {
        transform.position = Vector2.Lerp(transform.position, dest, Speed * Time.deltaTime);
    }

    public void GoRoute() { StartCoroutine("_GoRoute"); }
    private IEnumerator _GoRoute()
    {
        ClearRoute();
        GameObject[] myTargets = GameObject.FindGameObjectsWithTag("Target1");
        CurrRoute = Instantiate(LinePrefab);
        LineRenderer lr = CurrRoute.GetComponent<LineRenderer>();
        lr.positionCount = 0;
        GameObject o0 = gameObject;
        float distance = 0f;
        lr.widthMultiplier = 0.1f;

        for (int i=0; i<myTargets.Length; i++)
        {
            AddPoint2Line(lr, o0.transform.position);
            distance = Vector2.Distance(o0.transform.position, myTargets[i].transform.position);
            for (int j=0; j< myTargets.Length; j++)
                if (myTargets[j].GetComponent<CellScript>().ID==i)
                {
                    o0 = myTargets[j];
                    break;
                }

            yield return new WaitForSeconds(0.5f);
        }
        AddPoint2Line(lr, o0.transform.position);
    }

    private void AddPoint2Line(LineRenderer lr, Vector3 point)
    {
        lr.SetPosition(lr.positionCount++, point);
        lr.gameObject.GetComponent<LineScript>().UpdateDistance();
    }
    

    public void ClearRoute()
    {
        if (CurrRoute != null)
            Destroy(CurrRoute);

    }


}
