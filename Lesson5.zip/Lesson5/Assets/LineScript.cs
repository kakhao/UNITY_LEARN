﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LineScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void UpdateDistance()
    {
        float d = GetRouteDistance();
        GetComponentInChildren<TextMesh>().text = "Route Distance:" + d.ToString();

    }

    float GetRouteDistance()
    {
        float r = 0f;
        LineRenderer lr = GetComponent<LineRenderer>();
        Vector3[] LinePositions = new Vector3[lr.positionCount];
        lr.GetPositions(LinePositions);
        for (int i = 0; i < LinePositions.Length - 1; i++)
            r += Vector2.Distance(LinePositions[i], LinePositions[i + 1]);
        
        return r;
    }


}
