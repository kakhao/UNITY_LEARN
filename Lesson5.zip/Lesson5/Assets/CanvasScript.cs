﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CanvasScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public MainScript GetMainScript()
    {
        return GameObject.FindGameObjectWithTag("MainCamera").GetComponent<MainScript>();
    }
    public PersScript GetPersScript()
    {
        return GameObject.FindGameObjectWithTag("Player").GetComponent<PersScript>();
    }

    public void DoShuffle()
    {
        GetMainScript().ShuffleID();
    }
    public void DoOrder1()
    {
        GetMainScript().OrderID1();
    }
    public void DoOrder2()
    {
        GetMainScript().OrderID2();
    }
    public void DoMess()
    {
        GetMainScript().MessCells();
    }

    public void ShowRoute()
    {
        GetPersScript().GoRoute();
    }
    public void ClearRoute()
    {
        GetPersScript().ClearRoute();

    }


}
