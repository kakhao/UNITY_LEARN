﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class CellScript : MonoBehaviour
{
    // Start is called before the first frame update

    private int _ID = -1;

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    public int ID
    {
        get { return _ID; }
        set
        {
            _ID = value;
            UpdateText();
        }
    }


    private void UpdateText()
    {
        GetComponentInChildren<TextMesh>().text = ID.ToString();
        //GetComponentInChildren<Text>().text = ID.ToString();
    }

}
