﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainScript : MonoBehaviour
{
    // Start is called before the first frame update

    public GameObject CellPrefab;
    float lastMinSize = 0;
    public int NumberOfCells = 5;

    void Start()
    {
        InitCellsOnLine();
    }

    // Update is called once per frame
    void Update()
    {
        
    }


    private void InitCellsAtRandomPlaces()
    {
        for (int i = 0; i < NumberOfCells; i++)
        {
            GameObject g = Instantiate(CellPrefab, new Vector2(Random.Range(-10, 10), Random.Range(-5, 5)), Quaternion.identity);
            float a = Random.Range(0.5f, 5f);
            g.GetComponent<CellScript>().ID = i;
        }
    }
    private void InitCellsOnLine()
    {
        for (int i = 0; i < NumberOfCells; i++)
        {
            GameObject g = Instantiate(CellPrefab, new Vector2(i-10, 0f), Quaternion.identity);
            float a = Random.Range(0.5f, 5f);
            g.GetComponent<CellScript>().ID = i;
        }
    }

    public void ShuffleID() {StartCoroutine("_ShuffleID");}
    private IEnumerator _ShuffleID()
    {
        GameObject[] myTargets = GameObject.FindGameObjectsWithTag("Target1");
        for (int i = 0; i < myTargets.Length; i++)
        {
            swapID(myTargets[i], myTargets[Random.Range(0, myTargets.Length)]);
            yield return new WaitForSeconds(0.5f);
        }
    }
    public void OrderID1() { StartCoroutine("_OrderID1"); }
    private IEnumerator _OrderID1()
    {
        //WaitForSeconds wait = new WaitForSeconds(1f);
        GameObject[] myTargets = GameObject.FindGameObjectsWithTag("Target1");
        for (int i = 0; i < myTargets.Length-1; i++)
        {

            for (int j = i; j < myTargets.Length; j++)
                if (myTargets[j].GetComponent<CellScript>().ID ==i)
                {
                    swapID(myTargets[i], myTargets[j]);
                    break;
                }
            yield return new WaitForSeconds(0.5f);
        }
    }

    public void OrderID2() { StartCoroutine("_OrderID2"); }
    private IEnumerator _OrderID2()
    {
        //WaitForSeconds wait = new WaitForSeconds(1f);
        GameObject[] myTargets = GameObject.FindGameObjectsWithTag("Target1");
        for (int i = 0; i < myTargets.Length - 1; i++)
        {

            for (int j = 0; j < myTargets.Length-i-1; j++)
                if (myTargets[j].GetComponent<CellScript>().ID > myTargets[j+1].GetComponent<CellScript>().ID)
                {
                    swapID(myTargets[j], myTargets[j+1]);
                }
            yield return new WaitForSeconds(0.5f);
        }
    }

    public void MessCells() { StartCoroutine("_MessCells"); }
    private IEnumerator _MessCells()
    {
        //WaitForSeconds wait = new WaitForSeconds(1f);
        GameObject[] myTargets = GameObject.FindGameObjectsWithTag("Target1");
        foreach (GameObject go in myTargets)
        {
            go.transform.position = new Vector2(Random.Range(-10, 10), Random.Range(-5, 5));
            yield return new WaitForSeconds(0.5f);
        }
    }

    private void swapID(GameObject a, GameObject b)
    {
        //print("swaping");
        int ID0 = a.GetComponent<CellScript>().ID;
        a.GetComponent<CellScript>().ID = b.GetComponent<CellScript>().ID;
        b.GetComponent<CellScript>().ID = ID0;
    }


    GameObject FindMin()
    {
        GameObject[] myTargets = GameObject.FindGameObjectsWithTag("Target1");
        GameObject minGO = null;
        float minSize = 100f;

        foreach (GameObject go in myTargets)
            if ((go.transform.localScale.x < minSize) && (go.transform.localScale.x>lastMinSize))
            {
                minGO = go;
                minSize = minGO.transform.localScale.x;
            }
                
        if (minGO!=null)
            lastMinSize = minGO.transform.localScale.x;

       // print(lastMinSize);

        return minGO;
    }





}
